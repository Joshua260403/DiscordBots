import discord
import asyncio
from random import randint
from random import choice
import json
import os
import sys
import time
import pickle
import webbrowser
import this

client = discord.Client()

pfp = open("C:\\Users\\Joshua\\Desktop\\DynCode\\Discord\\Bots\\DynBot\\PF.png", 'rb')
pf = pfp.read()

#with open("muted.txt", "wb") as mutefile:
#	f = []
#	pickle.dump(f, mutefile)

with open("muted.txt", "rb") as mutefile:
	mut = pickle.load(mutefile)

@client.event
async def on_ready():
	#await client.edit_profile(password=None, avatar=pf)
	print('User:')
	print(client.user.name)
	print(client.user.id)
	print("-----------")
	await client.change_presence(game=discord.Game(name="Prefix: '&'"))
	
@client.event
async def on_message(message):
	if message.author.name in mut:
		await client.delete_message(message)
		pass
	role_names = [role.name for role in message.author.roles]
	server_names = [server.name for server in client.servers]
	#print(role_names)
	#print(message.author.name)
	#try:
	#	print(message.mentions[0])
	#except Exception:
	#	pass
	#print(server_names)
	#print(message.author)
	#print(message.author.roles)
	#print(role_names)
	#print(message.content[4:8])
	if 'Master' in role_names:
		if message.content.startswith('&say '):
			await client.send_message(message.channel, message.content[5:], tts=False)
		
		if message.content.startswith('&speak '):
			await client.send_message(message.channel, message.content[7:], tts=True)
		
		if message.content.startswith('&kick '):
			try:
				kickuser = message.mentions[0]
				role_names_ = [role.name for role in kickuser.roles]
				if not 'Admin' in role_names_:
					await client.kick(kickuser)
					print(kickuser + " got kicked")
			except Exception:
				pass
			
		if message.content.startswith('&exit'):
			sys.exit()
		
		if message.content.startswith('&test'):
			print('test')
			await client.send_message(message.channel, 'test', tts=True)
		
		if message.content.startswith('&bc '):
			para = message.content[4:8]
			if para == "&tts":
				await client.send_message(discord.Object(id='380060626942296064'), "@here " + message.content[9:], tts=True)
			else:
				await client.send_message(discord.Object(id='380060626942296064'), "@here " + message.content[4:], tts=False)
			
		
	if 'Mod' in role_names or 'Security' in role_names or 'Master' in role_names or 'Admin' in role_names:
		#print('role [Mod, Security or Master] detected')
		if message.content.startswith('&mute '):
			try:
				if 'Master' not in role_names:
					print(message.mentions[0].name)
					mut.append(message.mentions[0].name)
					print(mut)
			except Exception:
				print('Muting error')
				pass
			
		if message.content.startswith('&unmute '):
			try:
				mut.remove(message.mentions[0].name)
				print(mut)
			except Exception:
				print('Unmuting error')
				pass
				
		if message.content.startswith('&mutelist'):
			await client.send_message(message.channel, mut, tts=False)
	
	if message.content.startswith('&dice '):
		try:
			dice = int(message.content[6:8])
			try:
				test = dice + 7
				await client.send_message(message.channel, "Dice are being thrown, please wait!", tts=False)
				done = 0
				outcome = []
				while done < dice:
					done = done + 1
					random = randint(1,6)
					outcome.append(random)
				await client.send_message(message.channel, outcome, tts=True)
			except Exception:
				pass
		except Exception:
			pass
	
	if message.content.startswith('&coin'):
		await client.send_message(message.channel, "A coin is being flipped, please wait!", tts=False)
		await client.send_message(message.channel, choice([True, False]), tts=True)
		
	
	if message.content.startswith('&invite'):
		await client.send_message(message.author, "The public invitation link is: https://discord.gg/kGRaPKc")
	
#	if message.content.startswith('&like '):
#		#message.reactions = [\U0001f44e]
#		await asyncio.sleep(10)
#		print(message.reactions[0].emoji.id)
	
	if message.content.startswith('&web'):
		embed = discord.Embed(color=0x00ff00)
		"""!!!!!!!!!!!!!!!"""#!!!!!
		embed.add_field(name="Links:", value="[Google](https://www.google.nl/_/chrome/newtab?espv=2&ie=UTF-8)", inline=False)
		"""!!!!!!!!!!!!!!!"""#!!!!!
		await client.send_message(message.channel, embed=embed)
		
	if message.content.startswith('&run'):
			exe = " ".join(command[1:])
			exec(exe)
		
	with open("muted.txt", "wb") as mutefile:
		mutefile.truncate
		pickle.dump(mut, mutefile)

client.run('Mzg0NzM5NTk1MDQ2MDkyODAx.DQXkRQ.iNlgrylNkic3OOKRGT6MaNO8EVA')
