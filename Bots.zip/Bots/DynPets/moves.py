import sqlite3
from random import randint
from random import choice

attacks = {
"water_1" : ["splash", "spray"],
"water_2" : ["rain", "soak"],
"water_3" : ["watergun", "bubble"],

"fire_1" : ["heatup", "flare"],
"fire_2" : ["burn", "blaze"],
"fire_3" : ["burst", "erupt"],

"electric_1" : ["shock", "shockwave"],
"electric_2" : ["zap", "charge"],
"electric_3" : ["voltage"", ""bolt"]#,

#!!!#D#A#T#A#-#M#I#S#S#I#N#G##!!!#

}

types = ['water', 'fire', 'electric', 'earth', 'air', 'plant']

def getmove(type, set):
	move = choice(attacks[str(type) + "_" + str(set)])
	return move