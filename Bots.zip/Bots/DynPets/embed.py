import discord
import asyncio
from random import randint
from random import choice
import json
import os
import sys
import time
import sqlite3
import webbrowser

from core import *

def helpdocs():
	embed = discord.Embed(color=0xffff00)
	value="""
View someone's pets: %pets <@mention>
New pet: %newpet <name> <type>
Get a delete code: %delcode
Delete pet: %delpet <code> <name>

	"""
	embed.add_field(name="Help", value=value)
	embed.add_field(name="Types", value=types)
	return embed

def fetchpets(tag):
	embed = discord.Embed(title=tag + "'s pets:", color=0xff0000)
	pets = retstats(tag)
	for pet in pets:
		moves = pet[9].split('/')
		value = "\
level: " + str(pet[2]) + "\t\
xp: " + str(pet[3]) + "\n\
hp: " + str(pet[4]) + "\t\
attack: " + str(pet[5]) + "\n\
defense: " + str(pet[6]) + "\t\
speed: " + str(pet[7]) + "\n\
type: " + pet[8] + "\t\
moves:\n" 
		for move in moves:
			value = value + move + "\t"
		embed.add_field(name=pet[1], value=value, inline=False)
	return embed
