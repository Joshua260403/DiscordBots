"""
with open('data', 'wb') as file:
	f = {'example':[{'name':'sample',
					'level':18,
					'hp':50,
					'attack':20,
					'defense':15,
					'speed':15,
					'xp':1,
					'type':'water',
					'moves':['spray','rain']
					}]
		}
	file.truncate
	pickle.dump(f, file, protocol=pickle.HIGHEST_PROTOCOL)
"""

import sqlite3
from random import randint
from random import choice
from moves import *

file = sqlite3.connect('data.db')
db = file.cursor()

#db.execute("INSERT INTO pets VALUES ('Example', 'Sample', 1, 1, 50, 20, 20, 10, 'water', 'splash')")
#file.commit()

#Retrieve already existing pets from database:

"""
db.execute("SELECT * FROM pets")
rows = db.fetchall()
print(rows)
print(type(rows))
for row in rows:
	print(row)
	print(type(row))
"""

def savedb():
	file.commit()

def retstats(tag):
	param = [tag]
	#print(type(param))
	db.execute("SELECT * FROM pets WHERE owner = ?", param)
	results = db.fetchall()
	if results == []:
		raise ZeroDivisionError
		print(results)
	else:
		return results

def ownedpets(tag):
	param = [tag]
	db.execute("SELECT * FROM pets WHERE owner = ?", param)
	pets = db.fetchall()
	owned = 0
	for pet in pets:
		owned += 1
	return owned

def inspet(owner, name, type):
	att = randint(11, 23)
	dfs = randint(11, 23)
	tank = att + dfs
	spd = 50 - tank
	mvs = getmove(type, 1)
	stats = [owner, name, 1, 1, 50, att, dfs, spd, type, mvs]
	db.execute("INSERT INTO pets VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", stats)
	
def delpet(tag, pet):
	#try:
	param = [pet, tag]
	print('delpet: ' + pet)
	db.execute("DELETE FROM pets WHERE name = ? AND owner = ?", param)
	#except Exception:
	#	raise ZeroDivisionError
