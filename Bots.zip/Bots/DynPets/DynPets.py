import discord
import asyncio
from random import randint
from random import choice
from random import choices
import json
import os
import sys
import time
import sqlite3
import webbrowser
import pickle
import string

from core import *
from embed import *
from moves import *

client = discord.Client()

pfp = open("C:\\Users\\Joshua\\Desktop\\DynCode\\Discord\\Bots\\DynPets\\PF.png", 'rb')
pf = pfp.read()

with open("C:\\Users\\Joshua\\Desktop\\DynCode\\Discord\\Bots\\DynBot\\muted.txt", "rb") as mutefile:
	mut = pickle.load(mutefile)

passes = []

@client.event
async def on_ready():
	#await client.edit_profile(password=None, avatar=pf)
	print('User:')
	print(client.user.name)
	print(client.user.id)
	print("-----------")
	await client.change_presence(game=discord.Game(name="Prefix: '%'"))
	

@client.event
async def on_message(message):
	global passes
	if message.author.name in mut:
		pass
	try:
		global role_names
		role_names = [role.name for role in message.author.roles]
	except Exception:
		print('No roles!')
	msg = message.content.lower()
	command = msg.split()
	
	print(command)
	
	if command[0].startswith('%'):
		#print('\nCommand')
		#print(command[0])
		
		if 'Master' in role_names:
			
			#print('Master')
			
			if command[0] == '%exit':
				sys.exit()
				
			if command[0] == '%test':
				print('test')
				await client.send_message(message.channel, 'test', tts=True)
			
			if command[0] == '%run':
				exe = " ".join(command[1:])
				print('Atempting to run: ' + exe)
				
				exec(exe)
				
				#try:
					#exec(exe)
				#except Exception:
					#print('Error running: ' + exe)
					#pass
					
					
		
		if command[0] == '%help':
			await client.send_message(message.author, embed=helpdocs())
		
		if command[0] == '%pets':
			try:
				print(message.mentions[0])
			except Exception:
				pass
			else:
				try:
					#print('Tag')
					tag = str(message.mentions[0])[:-5]
					print(tag)
					await client.send_message(message.channel, embed=fetchpets(tag))
				except Exception:
					await client.send_message(message.channel, "Error, no pets were found for this user!")
					pass
				
		if command[0] == '%newpet':
			tag = str(message.author)[:-5]
			if ownedpets(tag) < 25:
				print(types)
				tp = command[2]
				print(tp)
				if tp in types:
					nm = command[1]
					print(nm)
					petnames = []
					try:
						pets = retstats(tag)
					except ZeroDivisionError:
						print('No pets yet.')
						inspet(tag, nm, tp)
						await client.send_message(message.channel, nm + " was created!")
					else:
						for pet in pets:
							petnames.append(pet[1])
						if nm not in petnames:
							print('Create reached')
							inspet(tag, nm, tp)
							await client.send_message(message.channel, nm + " was created!")
				else:
					await client.send_message(message.channel, tp + " is not a valid type!")
			else:
				await client.send_message(message.channel, "You have already reached the maximum amount of pets.")
				
		if command[0] ==  '%delcode':
			secpass = ''.join(choices(string.ascii_lowercase + string.digits, k=24))
			passes.append(secpass)
			sec = 60
			await client.send_message(message.author, secpass + "\nThis code will expire 60 seconds after this message has been sent!")
			while sec > 0:
				await asyncio.sleep(1)
				sec -= 1
			passes.pop(0)
				
		if command[0] == '%delpet':
			try:
				tag = str(message.author)[:-5]
				pet = " ".join(command[2:])
				cod = command[1]
				petnames = []
				pets = retstats(tag)
				for pet in pets:
					petnames.append(pet[1])
				print(pets)
				print(pet)
				#print(cod)
				#print(passes)
				if pet[1] in petnames:
					if cod in passes:
						delpet(tag, pet[1])
						await client.send_message(message.channel, pet[1] + " was succesfully deleted!")
					else:
						await client.send_message(message.channel, "Incorrect deletion code!")
				else:
					await client.send_message(message.channel, "You don't own a pet named " + pet[1] + "!")
			except ZeroDivisionError:
				print('No pets yet')
				if cod in passes:
					delpet(tag, pet[1])
					await client.send_message(message.channel, pet[1] + " was succesfully deleted!")
				else:
					await client.send_message(message.channel, "Incorrect deletion code!")
			
		
	savedb()

client.run('MzkzNDQ2MDEzNDA0MzE1NjQ4.DR15NA.scclARaoi0VlI3nJr2Nhhx9dS48')
